Original: https://github.com/atmoner/Bittystream/
